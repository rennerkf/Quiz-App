package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void submit(View view) {
        EditText nameField = (EditText) findViewById(R.id.name_field);
        String name = nameField.getText().toString();

        //figure out if user checked black rhino
        CheckBox rhinoCheckBox = (CheckBox) findViewById(R.id.question_6_rhino);
        boolean hasRhino = rhinoCheckBox.isChecked();

        //figure out if user wants checked snow leopard
        CheckBox snowLeopardCheckBox = (CheckBox) findViewById(R.id.question_6_snow_leopard);
        boolean hasSnowLeopard = snowLeopardCheckBox.isChecked();
        //figure out if user checked orangutan

        CheckBox orangutanCheckBox = (CheckBox) findViewById(R.id.question_6_orangutan);
        boolean hasOrangutan = orangutanCheckBox.isChecked();
        //figure out if user checked all the above
        CheckBox allTheAboveCheckBox = (CheckBox) findViewById(R.id.question_6_all_above);
        boolean hasAllTheAbove = allTheAboveCheckBox.isChecked();

        if(hasRhino && hasOrangutan && hasSnowLeopard && hasAllTheAbove || hasAllTheAbove|| hasOrangutan && hasRhino && hasSnowLeopard){

        } else {

        }

        Toast.makeText(MainActivity.this, "Your score is " + score, Toast.LENGTH_SHORT).show();
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio_button1:
                if (checked)
                    R.id.radio_button1.setTextColor(Color.GREEN);
                score = score + 1;
                    break;
            case R.id.radio_button2:
                if (checked)
                    // not correct
                    setTextColor(Color.RED);
                    break;
            case R.id.radio_button3:
                if (checked)
                    // not correct
                    setTextColor(Color.RED);
                    break;
        }
    }

    }